<template>
    <div class="row mx-auto w-90 mt-3 profils administration">
    	<div class="w-95 mx-auto">
            <table class="table table-official text-white">
                <thead>
                    <th>No</th>
                    <th>ID Ref.</th>
                    <th>Nom et prénoms</th>
                    <th>Actions</th>
                </thead>
                <tbody>
                    <tr>
                        <td>12</td>
                        <td>25485445</td>
                        <td>HOUNDEKINDO</td>
                        <td>Delete</td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>25485445</td>
                        <td>HOUNDEKINDO</td>
                        <td>Delete</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
	import { mapState } from 'vuex'
	export default {
        data() {
            return {
                
            }   
        },
		
        created(){
           
        },
        methods :{
           
            
        },

        computed: mapState([
            
        ])
	}
</script>

<style>
  
</style>