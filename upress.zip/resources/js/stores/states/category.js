const category_s = {
	category: {},
	categories: [],
	newCategory: {

	},
	newCategoryInvalids: {status: false, msg: ''},
}

export default category_s