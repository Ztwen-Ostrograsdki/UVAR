const member_s = {
	member: {id: '', name: ''},
	myAccount: {},
	myReferer: {},
	members: [],
	myActions: [],
	myReferies: [],
	myProducts: [],
	myBonuses: [],
	memberReady: false,
	newReferee: {email: undefined},
	affiliationsInvalids: {status: false, msg: ''},
	invalidsEditMember: {},
	editingMember: {},
	memberPhoto: {},
	active_member_photo: {},
	isLoadedMembers: false,
	isLoadedMember: false,
}

export default member_s