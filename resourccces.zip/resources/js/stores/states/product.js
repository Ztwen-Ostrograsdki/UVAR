const product_s = {
	editingProduct: {},
	targetedProduct: {},
	allProductsOnlyAPart: [],
	boughtedProducts: [],
	invalidsEditProduct: {},
	bestProduct: {},
	lastProduct: {},
	invalidsEditProduct: {},
	product: {product: {}, buyers: [], totalBought: 0, last: {}, first: {}},
	allProducts: [],
	products: [],
	newProduct: {
		name: '',
		description: '',
		total: '',
		price: '',
	},
	invalidsNewProduct: {},
	totalBoughtByProduct: [],
	isLoadedProducts: false,
	isLoadedSelectedProducts: false,
	selectedProducts: [],
	isLoadedProduct: false,
}

export default product_s